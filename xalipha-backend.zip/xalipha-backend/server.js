require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');

const authRoutes = require('./routes/auth');
const messageRoutes = require('./routes/messages');
const serviceRoutes = require('./routes/services');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Sert l'interface admin statique (HTML/CSS/JS) sur /admin
app.use('/admin', express.static(path.join(__dirname, 'public/admin')));

// Sert le site vitrine si le fichier index.html est placé dans /public
app.use(express.static(path.join(__dirname, 'public')));

// ---------- Routes API ----------
app.use('/api/auth', authRoutes);
app.use('/api/contact', messageRoutes); // POST /api/contact (public)
app.use('/api/messages', messageRoutes); // GET/PATCH/DELETE /api/messages/admin/... (protégé)
app.use('/api/services', serviceRoutes);

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

app.use((req, res) => {
  res.status(404).json({ error: 'Route introuvable.' });
});

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Erreur serveur interne.' });
});

app.listen(PORT, () => {
  console.log(`\n🚀 Serveur Xalipha démarré sur http://localhost:${PORT}`);
  console.log(`   - API contact  : POST http://localhost:${PORT}/api/contact`);
  console.log(`   - API services : GET  http://localhost:${PORT}/api/services`);
  console.log(`   - Interface admin : http://localhost:${PORT}/admin\n`);
});
