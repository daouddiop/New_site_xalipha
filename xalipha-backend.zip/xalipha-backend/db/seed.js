// Ce script initialise la base : crée un compte admin et quelques services de départ.
// Lancer avec : npm run seed
require('dotenv').config();
const bcrypt = require('bcryptjs');
const db = require('./database');

const ADMIN_EMAIL = process.env.ADMIN_EMAIL || 'admin@xalipha.sn';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'ChangeMoi123!';

function seedAdmin() {
  const existing = db.prepare('SELECT id FROM admins WHERE email = ?').get(ADMIN_EMAIL);
  if (existing) {
    console.log(`Un admin existe déjà pour ${ADMIN_EMAIL}, on ne le recrée pas.`);
    return;
  }
  const hash = bcrypt.hashSync(ADMIN_PASSWORD, 10);
  db.prepare('INSERT INTO admins (email, password_hash) VALUES (?, ?)').run(ADMIN_EMAIL, hash);
  console.log('✅ Compte admin créé :');
  console.log(`   Email    : ${ADMIN_EMAIL}`);
  console.log(`   Password : ${ADMIN_PASSWORD}`);
  console.log('   (modifiable dans le fichier .env avec ADMIN_EMAIL / ADMIN_PASSWORD avant le seed)');
}

function seedServices() {
  const count = db.prepare('SELECT COUNT(*) AS c FROM services').get().c;
  if (count > 0) {
    console.log('Des services existent déjà, on ne réinsère pas les exemples.');
    return;
  }
  const insert = db.prepare(
    'INSERT INTO services (titre, description, icone, ordre, actif) VALUES (?, ?, ?, ?, 1)'
  );
  const defaults = [
    ['Développement Web', "Sites vitrines, e-commerce, apps web. Modernes, rapides et optimisés pour le référencement.", '💻', 1],
    ['Applications Mobiles', "Apps iOS et Android performantes. Design soigné et expérience utilisateur fluide.", '📱', 2],
    ['IA Générative & Chatbots', "Chatbots intelligents, assistants virtuels et automatisation propulsés par l'IA.", '🤖', 3],
  ];
  const insertMany = db.transaction((rows) => {
    for (const row of rows) insert.run(...row);
  });
  insertMany(defaults);
  console.log('✅ Services de départ insérés.');
}

seedAdmin();
seedServices();
console.log('\nInitialisation terminée.');
