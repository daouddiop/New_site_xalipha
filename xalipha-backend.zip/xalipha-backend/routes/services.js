const express = require('express');
const db = require('../db/database');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

// GET /api/services -> PUBLIC : liste des services actifs, utilisée par le site vitrine
router.get('/', (req, res) => {
  const rows = db
    .prepare('SELECT * FROM services WHERE actif = 1 ORDER BY ordre ASC, id ASC')
    .all();
  res.json(rows);
});

// GET /api/services/admin/all -> ADMIN : tous les services, actifs ou non
router.get('/admin/all', requireAuth, (req, res) => {
  const rows = db.prepare('SELECT * FROM services ORDER BY ordre ASC, id ASC').all();
  res.json(rows);
});

// POST /api/services -> ADMIN : créer un service
router.post('/', requireAuth, (req, res) => {
  const { titre, description, icone, ordre, actif } = req.body;
  if (!titre) {
    return res.status(400).json({ error: 'Le titre du service est obligatoire.' });
  }
  const info = db
    .prepare(
      'INSERT INTO services (titre, description, icone, ordre, actif) VALUES (?, ?, ?, ?, ?)'
    )
    .run(titre.trim(), description || '', icone || '✨', ordre || 0, actif === false ? 0 : 1);

  const created = db.prepare('SELECT * FROM services WHERE id = ?').get(info.lastInsertRowid);
  res.status(201).json(created);
});

// PUT /api/services/:id -> ADMIN : modifier un service
router.put('/:id', requireAuth, (req, res) => {
  const { id } = req.params;
  const existing = db.prepare('SELECT * FROM services WHERE id = ?').get(id);
  if (!existing) {
    return res.status(404).json({ error: 'Service introuvable.' });
  }

  const titre = req.body.titre ?? existing.titre;
  const description = req.body.description ?? existing.description;
  const icone = req.body.icone ?? existing.icone;
  const ordre = req.body.ordre ?? existing.ordre;
  const actif = req.body.actif === undefined ? existing.actif : req.body.actif ? 1 : 0;

  db.prepare(
    'UPDATE services SET titre = ?, description = ?, icone = ?, ordre = ?, actif = ? WHERE id = ?'
  ).run(titre, description, icone, ordre, actif, id);

  const updated = db.prepare('SELECT * FROM services WHERE id = ?').get(id);
  res.json(updated);
});

// DELETE /api/services/:id -> ADMIN : supprimer un service
router.delete('/:id', requireAuth, (req, res) => {
  const { id } = req.params;
  const result = db.prepare('DELETE FROM services WHERE id = ?').run(id);
  if (result.changes === 0) {
    return res.status(404).json({ error: 'Service introuvable.' });
  }
  res.json({ success: true });
});

module.exports = router;
