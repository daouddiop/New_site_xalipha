const express = require('express');
const db = require('../db/database');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

// POST /api/contact  -> Route PUBLIQUE utilisée par le formulaire du site
router.post('/', (req, res) => {
  const { prenom, nom, email, telephone, service, message } = req.body;

  if (!prenom || !nom || !email || !telephone) {
    return res.status(400).json({ error: 'Prénom, nom, email et téléphone sont obligatoires.' });
  }
  if (!isValidEmail(email)) {
    return res.status(400).json({ error: "L'adresse email n'est pas valide." });
  }

  const stmt = db.prepare(`
    INSERT INTO messages (prenom, nom, email, telephone, service, message)
    VALUES (?, ?, ?, ?, ?, ?)
  `);
  const info = stmt.run(
    prenom.trim(),
    nom.trim(),
    email.trim(),
    telephone.trim(),
    service || null,
    message || null
  );

  res.status(201).json({
    success: true,
    id: info.lastInsertRowid,
    message: 'Message enregistré avec succès.',
  });
});

// GET /api/messages -> Route ADMIN : liste tous les messages (les plus récents d'abord)
router.get('/admin/list', requireAuth, (req, res) => {
  const rows = db.prepare('SELECT * FROM messages ORDER BY created_at DESC').all();
  res.json(rows);
});

// PATCH /api/messages/:id/lu -> Route ADMIN : marquer un message comme lu/non lu
router.patch('/admin/:id/lu', requireAuth, (req, res) => {
  const { id } = req.params;
  const { lu } = req.body;
  const result = db.prepare('UPDATE messages SET lu = ? WHERE id = ?').run(lu ? 1 : 0, id);
  if (result.changes === 0) {
    return res.status(404).json({ error: 'Message introuvable.' });
  }
  res.json({ success: true });
});

// DELETE /api/messages/:id -> Route ADMIN : supprimer un message
router.delete('/admin/:id', requireAuth, (req, res) => {
  const { id } = req.params;
  const result = db.prepare('DELETE FROM messages WHERE id = ?').run(id);
  if (result.changes === 0) {
    return res.status(404).json({ error: 'Message introuvable.' });
  }
  res.json({ success: true });
});

module.exports = router;
